const mongoose = require('mongoose');
const { Schema } = mongoose;

const PaymentSchema = new Schema({
  // Company that made the payment (null for registration payments, updated after verification)
  companyId: {
    type: Schema.Types.ObjectId,
    ref: 'Company',
    required: false,
    index: true,
  },

  // User who initiated the payment (null for registration payments, updated after verification)
  userId: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: false,
  },

  // Denormalized company/user info — preserves names even if company/user is deleted
  companyName: {
    type: String,
    required: false,
  },
  companyEmail: {
    type: String,
    required: false,
  },
  userName: {
    type: String,
    required: false,
  },
  userEmail: {
    type: String,
    required: false,
  },

  // Subscription plan purchased (null for recharge payments)
  subscriptionId: {
    type: Schema.Types.ObjectId,
    ref: 'Subscription',
    required: false,
  },

  // What this payment is for
  paymentFor: {
    type: String,
    enum: ['subscription', 'recharge'],
    default: 'subscription',
  },

  // Linked recharge (null for subscription payments)
  rechargeId: {
    type: Schema.Types.ObjectId,
    ref: 'Recharge',
    sparse: true,
  },

  // Plan details at time of purchase (optional for recharge payments)
  planName: {
    type: String,
    required: false,
  },
  planDuration: {
    type: Number,
    required: false, // in days; not required for one-time recharge payments
  },

  // Amount details
  amount: {
    type: Number,
    required: true,
  },
  currency: {
    type: String,
    default: 'INR',
  },
  billingCycle: {
    type: String,
    enum: ['monthly', 'yearly', 'one_time'],
    required: true,
  },

  // Razorpay IDs (used for subscription payments)
  razorpayOrderId: {
    type: String,
    sparse: true,
  },
  razorpayPaymentId: {
    type: String,
    sparse: true,
  },
  razorpaySignature: {
    type: String,
    sparse: true,
  },

  // Payment gateway used
  gateway: {
    type: String,
    enum: ['razorpay', 'payu'],
    default: 'razorpay',
  },

  // PayU IDs (used for recharge payments)
  payuTxnId: {
    type: String,
    sparse: true,
  },
  payuMihpayId: {
    type: String,
    sparse: true,
  },
  payuHash: {
    type: String,
    sparse: true,
  },

  // Payment status
  status: {
    type: String,
    enum: ['created', 'pending', 'completed', 'failed', 'refunded', 'cancelled'],
    default: 'created',
    index: true,
  },

  // Payment method (from Razorpay or PayU)
  paymentMethod: {
    type: String,
    enum: ['card', 'netbanking', 'wallet', 'upi', 'emi', 'card_emi', 'other'],
    sparse: true,
  },

  // Bank/Card info (from Razorpay or PayU)
  bank: String,
  wallet: String,
  vpa: String, // UPI ID
  cardId: String,
  cardLast4: String,
  cardNetwork: String,

  // Timestamps
  paidAt: Date,
  failedAt: Date,
  refundedAt: Date,
  cancelledAt: Date,

  // Refund details
  refundAmount: Number,
  refundReason: String,

  // Invoice
  invoiceNumber: {
    type: String,
    sparse: true,
    unique: true,
  },

  // Notes
  notes: String,
}, {
  timestamps: true,
});

// Indexes
PaymentSchema.index({ companyId: 1, status: 1 });
PaymentSchema.index({ createdAt: -1 });
PaymentSchema.index({ payuTxnId: 1 }, { unique: true, sparse: true });

// Generate invoice number before saving
PaymentSchema.pre('save', async function(next) {
  if (this.status === 'completed' && !this.invoiceNumber) {
    const count = await mongoose.models.Payment.countDocuments({
      status: 'completed',
      invoiceNumber: { $exists: true }
    });
    const year = new Date().getFullYear();
    const month = String(new Date().getMonth() + 1).padStart(2, '0');
    this.invoiceNumber = `INV-${year}${month}-${String(count + 1).padStart(5, '0')}`;
  }
  next();
});

// Static methods
PaymentSchema.statics.findByCompany = function(companyId, options = {}) {
  const query = { companyId };
  if (options.status) query.status = options.status;

  return this.find(query)
    .populate('subscriptionId', 'name')
    .populate('userId', 'name email')
    .sort({ createdAt: -1 })
    .limit(options.limit || 50);
};

PaymentSchema.statics.findCompletedByCompany = function(companyId) {
  return this.findOne({ companyId, status: 'completed' })
    .sort({ createdAt: -1 })
    .populate('subscriptionId');
};

PaymentSchema.statics.getTotalRevenue = async function() {
  const result = await this.aggregate([
    { $match: { status: 'completed' } },
    { $group: { _id: null, total: { $sum: '$amount' }, count: { $sum: 1 } } }
  ]);
  return result[0] || { total: 0, count: 0 };
};

PaymentSchema.statics.getMonthlyRevenue = async function(year, month) {
  const startDate = new Date(year, month - 1, 1);
  const endDate = new Date(year, month, 0);

  const result = await this.aggregate([
    {
      $match: {
        status: 'completed',
        paidAt: { $gte: startDate, $lte: endDate }
      }
    },
    { $group: { _id: null, total: { $sum: '$amount' }, count: { $sum: 1 } } }
  ]);
  return result[0] || { total: 0, count: 0 };
};

// Instance methods — Razorpay (for subscription payments)
PaymentSchema.methods.markCompleted = function(paymentData) {
  this.status = 'completed';
  this.razorpayPaymentId = paymentData.razorpay_payment_id;
  this.razorpaySignature = paymentData.razorpay_signature;
  this.paymentMethod = paymentData.paymentMethod;
  this.bank = paymentData.bank;
  this.wallet = paymentData.wallet;
  this.vpa = paymentData.vpa;
  this.cardId = paymentData.card_id;
  this.cardLast4 = paymentData.card_last4;
  this.cardNetwork = paymentData.card_network;
  this.paidAt = new Date();
  return this.save();
};

// Instance methods — PayU (for recharge payments)
PaymentSchema.methods.markCompletedFromPayu = function(payuData) {
  this.status = 'completed';
  this.payuMihpayId = payuData.mihpayid || '';
  this.paymentMethod = payuData.paymentMethod || payuData.mode || 'other';
  this.bank = payuData.bankcode || '';
  this.cardLast4 = payuData.cardnum ? payuData.cardnum.slice(-4) : '';
  this.cardNetwork = payuData.cardtype || '';
  this.vpa = payuData.vpa || '';
  this.paidAt = new Date();
  return this.save();
};

PaymentSchema.methods.markFailed = function(reason) {
  this.status = 'failed';
  this.notes = (this.notes ? this.notes + ' ' : '') + reason;
  this.failedAt = new Date();
  return this.save();
};

PaymentSchema.methods.markCancelled = function(reason) {
  this.status = 'cancelled';
  this.notes = (this.notes ? this.notes + ' ' : '') + reason;
  this.cancelledAt = new Date();
  return this.save();
};

PaymentSchema.methods.markRefunded = function(amount, reason) {
  this.status = 'refunded';
  this.refundAmount = amount;
  this.refundReason = reason;
  this.refundedAt = new Date();
  return this.save();
};

module.exports = mongoose.model('Payment', PaymentSchema);